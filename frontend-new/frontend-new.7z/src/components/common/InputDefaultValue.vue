<script>
export default {
  name: 'InputDefaultValue',
  functional: true,
  components: { },
  data() {
    return {

    }
  },
  computed: {

  },
  watch: {

  },
  beforeCreate() {

  },
  methods: {

  },
  render(createElement, context) {
    return createElement(
      appropriateListComponent(),
      context.data,
      context.children
    )
  }
}
</script>
