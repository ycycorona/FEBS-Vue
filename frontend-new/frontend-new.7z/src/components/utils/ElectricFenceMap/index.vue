<template>
  <div style="width: 100%;height:500px;position:relative">
    <div class="search-info-wrap">
      <a-input id="map-text-search" addon-before="输入位置关键字检索" />
    </div>
    <div style="width: 100%;height:500px" />
  </div>
</template>

<script>

import { lazyAMapApiLoaderInstance } from 'vue-amap'

export default {
  name: 'ElectricFenceMap',
  props: {

  },
  data() {
    return {
      aMapIns: null,
      currentCircle: null,
      mouseTool: null,
      circleEditor: null,
      isEditCircleToolOn: false,
      circleData: {
        lng: '',
        lat: '',
        radius: ''
      },
      geocoder: null,
      autocomplete: null
    }
  },
  computed: {

  },
  watch: {
    currentCircle(newVal) {
      if (newVal) {
        this.$emit('have-current-circle')
      } else {
        this.$emit('no-current-circle')
      }
    }
  },
  mounted() {
    lazyAMapApiLoaderInstance.load().then(() => {
      this.mapInit()
      this.$emit('map-init-success')
      console.log('高德地图初始化完成')
      // eslint-disable-next-line
      this.mouseTool = new AMap.MouseTool(this.aMapIns)
      // eslint-disable-next-line
      this.geocoder = new AMap.Geocoder()
      // eslint-disable-next-line
      this.autocomplete =  new AMap.Autocomplete({input: "map-text-search"})
      this.autocomplete.on('select', ({ poi, type }) => {
        if (poi.location) {
          this.setCenterPoint(poi.location.lng, poi.location.lat)
        }
      })
      // 画圈完成回调函数
      // eslint-disable-next-line
      AMap.event.addListener(this.mouseTool, 'draw', (e) => {
        this.currentCircle = e.obj
        this.mouseTool.close()
        this.aMapIns.setDefaultCursor()
        this.$emit('add-circle-tool-off')
        this.currentCircle.setRadius(Math.round(this.currentCircle.getRadius()))
        this.circleChange({ lng: this.currentCircle.getCenter().getLng(),
          lat: this.currentCircle.getCenter().getLat(),
          radius: this.currentCircle.getRadius() })
        this.getCenterAddressName()
        this.$emit('fence-change', Object.assign({}, this.circleData))
      })
    })
  },
  methods: {
    mapInit() {
      // eslint-disable-next-line
      this.aMapIns = new AMap.Map(this.$el, {
        resizeEnable: true, // 是否监控地图容器尺寸变化
        zoom: 15
        // mapStyle: 'amap://styles/light'
      })
      // eslint-disable-next-line
      const scale = new AMap.Scale({
        visible: true
      })
      // eslint-disable-next-line
      const toolBar = new AMap.ToolBar({
        visible: true
      })
      this.aMapIns.addControl(scale) // 添加比例尺
      this.aMapIns.addControl(toolBar) // 添加工具栏
    },
    // 设置地图中心点
    setCenterPoint(lng, lat) {
      this.aMapIns.setCenter([lng, lat])
    },
    // 激活画圈插件
    activeAddCircleTool() {
      this.aMapIns.setDefaultCursor('crosshair')
      this.mouseTool.circle()
      this.$emit('add-circle-tool-on')
    },
    // 激活编辑圈的插件
    activeEditCircleTool() {
      if (!this.currentCircle) {
        this.$message.error('请先在地图上添加围栏')
        return
      }
      // eslint-disable-next-line
      this.circleEditor = new AMap.CircleEditor(this.aMapIns, this.currentCircle)
      this.circleEditor.on('end', (e) => {
        this.circleChange({ lng: this.currentCircle.getCenter().getLng(),
          lat: this.currentCircle.getCenter().getLat(),
          radius: this.currentCircle.getRadius() })
        this.getCenterAddressName()
        this.$emit('fence-change', Object.assign({}, this.circleData))
      })
      this.circleEditor.open()
      this.isEditCircleToolOn = true
      this.$emit('circle-editor-on')
    },
    // 取消激活编辑圈的插件
    deActiveEditCircleTool() {
      this.circleEditor.close()
      this.isEditCircleToolOn = false
      this.$emit('circle-editor-off')
    },
    // 从地图移除当前圆圈，并消除变量引用
    delCurrentCircle() {
      if (!this.currentCircle) { return }
      if (this.isEditCircleToolOn) {
        this.deActiveEditCircleTool()
      }
      this.currentCircle.setMap(null)
      this.currentCircle = null
    },
    // 手动设置圆属性
    manualChangeCircle({ lng, lat, radius }) {
      if (!this.currentCircle) {
        this.addFenceFromParams(lng, lat, radius)
        return
      }
      console.log(lng, lat, radius)
      this.currentCircle.setOptions({
        // eslint-disable-next-line
        radius, center: new AMap.LngLat(lng, lat)
      })
      this.circleChange({ lng, lat, radius })
      this.getCenterAddressName()
    },
    circleChange(obj) {
      // lng, lat, radius
      const emptyObj = {}
      Object.assign(emptyObj, this.circleData, obj)
      this.circleData = emptyObj
    },
    // 获取中心坐标地址
    getCenterAddressName() {
      return new Promise((resolve, reject) => {
        this.geocoder.getAddress([this.circleData.lng, this.circleData.lat], (status, result) => {
          if (status === 'complete' && result.regeocode) {
            this.$emit('center-address', result.regeocode.formattedAddress)
            resolve(result.regeocode.formattedAddress)
          } else {
            reject('根据经纬度查询地址失败')
            console.error('根据经纬度查询地址失败')
          }
        })
      })
    },
    // 从参数新建圆圈
    addFenceFromParams(lng, lat, radius) {
      // eslint-disable-next-line
      const circle = new AMap.Circle({
        // eslint-disable-next-line
        center: new AMap.LngLat(lng, lat), // 圆心位置
        radius: radius, // 半径
        strokeColor: '#1791fc',
        strokeOpacity: 0.8,
        strokeDasharray: [10, 5],
        strokeWeight: 2,
        strokeStyle: 'solid',
        fillColor: '#1791fc',
        fillOpacity: 0.35
      })
      if (this.currentCircle) {
        this.delCurrentCircle()
      }
      circle.setMap(this.aMapIns)
      this.setCenterPoint(Number(lng), Number(lat))
      this.currentCircle = circle
    }
  }
}
</script>

<style>

</style>

<style lang="less" scoped>
.search-info-wrap {
  position: absolute;
  top: 10px;
  right: 10px;
  padding: 10px;
  box-shadow: 0 2px 6px 0 rgba(114, 124, 245, .5);
  border-width: 0;
  border-radius: .25rem;
  background-color: #ffffff;
  z-index: 1;
}
</style>
