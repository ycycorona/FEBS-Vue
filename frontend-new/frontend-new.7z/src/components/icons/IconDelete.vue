<template>
  <a-icon :component="svg"></a-icon>
</template>

<script>
import svg from '@/assets/icons/delete.svg'

export default {
  name: 'IconDelete',
  data() {
    return {
      svg
    }
  }
}
</script>
<style>

</style>
