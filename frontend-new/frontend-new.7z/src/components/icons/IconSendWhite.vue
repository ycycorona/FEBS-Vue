<template>
  <a-icon :component="svg"></a-icon>
</template>

<script>
import svg from '@/assets/icons/send-white.svg'
export default {
  name: 'IconSend',
  data() {
    return {
      svg
    }
  }
}
</script>
<style>

</style>
