<template>
  <a-icon :component="svg"></a-icon>
</template>

<script>
import svg from '@/assets/icons/device-manage.svg'
export default {
  name: 'IconDeviceManage',
  data() {
    return {
      svg
    }
  }
}
</script>
<style>

</style>
