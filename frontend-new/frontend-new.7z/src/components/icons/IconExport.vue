<template>
  <a-icon :component="svg"></a-icon>
</template>

<script>
import svg from '@/assets/icons/export.svg'

export default {
  name: 'IconExport',
  data() {
    return {
      svg
    }
  }
}
</script>
<style>

</style>
