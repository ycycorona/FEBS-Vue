<template>
  <a-icon :component="svg"></a-icon>
</template>

<script>
import svg from '@/assets/icons/strategy-manage.svg'

export default {
  name: 'IconStrategyManage',
  data() {
    return {
      svg
    }
  }
}
</script>
<style>

</style>
