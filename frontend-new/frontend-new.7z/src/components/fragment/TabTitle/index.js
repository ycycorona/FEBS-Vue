import TabTitle from './TabTitle'
export default TabTitle
