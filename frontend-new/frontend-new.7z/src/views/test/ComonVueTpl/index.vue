<template>
  <div class="">

  </div>
</template>

<script>

export default {
  name: 'Name',
  components: { },
  props: {
    example: {
      default: false,
      type: Boolean
    }

  },
  data() {
    return {

    }
  },
  computed: {

  },
  watch: {

  },
  beforeCreate() {

  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
