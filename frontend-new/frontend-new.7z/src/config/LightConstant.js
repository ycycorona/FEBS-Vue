export const LightName = '智能灯'
export const GatewayName = '网关'
export const BasePosition = [120.384938, 36.107712]
